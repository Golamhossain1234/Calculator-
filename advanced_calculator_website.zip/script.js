
// script.js
let screen = document.getElementById("screen");
let currentInput = "";

function appendNumber(number) {
  currentInput += number;
  screen.textContent = currentInput;
}

function appendOperator(operator) {
  if (currentInput === "") return;
  if (/[+\-*/]$/.test(currentInput)) return;
  currentInput += operator;
  screen.textContent = currentInput;
}

function clearScreen() {
  currentInput = "";
  screen.textContent = "0";
}

function backspace() {
  currentInput = currentInput.slice(0, -1);
  screen.textContent = currentInput || "0";
}

function calculate() {
  try {
    currentInput = eval(currentInput).toString();
    screen.textContent = currentInput;
  } catch (error) {
    screen.textContent = "Error";
    currentInput = "";
  }
}

function toggleSign() {
  if (currentInput.startsWith("-")) {
    currentInput = currentInput.slice(1);
  } else if (currentInput !== "") {
    currentInput = "-" + currentInput;
  }
  screen.textContent = currentInput;
}

function squareRoot() {
  try {
    currentInput = Math.sqrt(eval(currentInput)).toString();
    screen.textContent = currentInput;
  } catch (error) {
    screen.textContent = "Error";
    currentInput = "";
  }
}

function calculateTrig(func) {
  try {
    const radians = (Math.PI / 180) * eval(currentInput);
    switch (func) {
      case "sin":
        currentInput = Math.sin(radians).toString();
        break;
      case "cos":
        currentInput = Math.cos(radians).toString();
        break;
      case "tan":
        currentInput = Math.tan(radians).toString();
        break;
    }
    screen.textContent = currentInput;
  } catch (error) {
    screen.textContent = "Error";
    currentInput = "";
  }
}
